package com.alfianyusufabdullah.footballschedule.data.local

import com.alfianyusufabdullah.footballschedule.data.entity.ScheduleResponse

interface LocalDataSourceImpl {
    fun setScheduleCache(scheduleResponse: ScheduleResponse)
    fun getScheduleCache(): ScheduleResponse
}