package com.alfianyusufabdullah.footballschedule.data.local

import android.content.Context
import com.alfianyusufabdullah.footballschedule.data.entity.ScheduleResponse


class LocalDataSource(private val context: Context) : LocalDataSourceImpl {
    
    override fun setScheduleCache(scheduleResponse: ScheduleResponse) {
    }

    override fun getScheduleCache(): ScheduleResponse {
    }
}