package com.alfianyusufabdullah.footballschedule.data.remote

interface RemoteDataSourceImpl {
    fun getSchedule() : String
}